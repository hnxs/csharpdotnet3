﻿/*Program: AvgGrade
 * Name: HEather Smith
 * Date: 4-27/16
 * Class: PRG205
 * 
 * Program that will allow the user to enter
 * in values that iwill then use a sentinel value
 * to store the input. Then will calculate the average,
 * and then test the average to determine what letter grade
 * is to be used
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRG205__FINAL_HeatherSmith
{
    class AvgGrade
    {
        static void Main(string[] args)
        {
            //Declare variables
            bool enterMoreScores = true;
            int totalScoresPerStudent, countOfScoresEntered;
            double average;
            char grade;

            DisplayInstructions();
            do
            {
                totalScoresPerStudent = 0;
                countOfScoresEntered = PromptForAllScoresForOneStudent(ref totalScoresPerStudent);
                average = CalculateAverage(countOfScoresEntered, totalScoresPerStudent);
                grade = GetGrade(average);
                DisplayResults(countOfScoresEntered, average, grade);
                enterMoreScores = GetInput();
            }
            while (enterMoreScores);
            Console.ReadKey();
        }

        //Display instructions on the screen
        static void DisplayInstructions()
        {
            Console.WriteLine("*********************************************************************************************" + "\n *** You will be prompted to input scores ranging from 0 to 100. ***" + "\n ***   The scores entered will be averaged and a letter grade    ***" + "\n ***   assigned. The results will then be displayed.be YOu may enter ***" + "\n as many sets of scores as you would like.              ***" + "\n ***                                     ***" + "\n ***              Enter as nevgative value to stop entering scores.          ***" + "\n *********************************************************************************" + "\n\n\n\tPress any key when you are ready to begin...");
         Console.ReadKey();
         Console.Clear();

        }

        //determine if you want to enter in anymore input
        static bool GetInput()
        {
            char input;
            bool enterMoreData;
            Console.Write("\n\nWould you like to enter another set of scores: " + "\nPlease enter 'Y' for YES or any other letter for NO...");
            if (char.TryParse(Console.ReadLine(), out input) == false) // In case they enter in more than one charachter
            {
                    input = 'n';
            }
            //Determine if I want to enter more data or not
            switch (input)
            {
                case 'y':
                case 'Y': enterMoreData = true;
                    break;
                default: enterMoreData = false;
                    break;

            }

            return enterMoreData;
        }
        //while statement for the inputting of grades
        static int PromptForAllScoresForOneStudent(ref int totalScores)
        {
            int numberOFScores = 0, score;

            score = ReturnValidScore();
            while (score > -1)
            {
                totalScores += score;
                numberOFScores += 1;
                score = ReturnValidScore();
            }
            return numberOFScores;
        }
        //input grades
        public static int ReturnValidScore()
        {
            string input;
            int score;
          
            Console.Write("\nPlease enter a score 0 - 100 ." + "\nEnter a number LESS than 0 to stop entering scores: ");
            input = Console.ReadLine();
            while (int.TryParse(input, out score) == false)
            {
                Console.Write("Invalid data entered - please re-enter the score: ");
            }
            return score;
          }

        //get average of grades entered
        public static double CalculateAverage(int numberOfScores, int totalScores)
        {
            double average;
            if (numberOfScores > 0)
            {
                average = (double)totalScores / numberOfScores;
            }
            else
            {
                average = 0;
            }
              return average;
         }
         
        //determine letter grade from average
         public static char GetGrade(double average)
         {
             char letterGrade;
             if (average > 89.49)
             {
                 letterGrade = 'A';
             }
             else
                 if(average > 79.49)
                 {
                     letterGrade = 'B';
                 }
                 else
                     if(average > 69.49)
                     {
                         letterGrade = 'C';
                     }
                     else 
                         if(average > 59.49)
                         {
                             letterGrade = 'D';
                         }
                         else
                         {
                             letterGrade = 'F';
                         }
             return letterGrade;
         }

        static void DisplayResults(int numberOfScores, double average, char letterGrade)
        {
            if (numberOfScores != 0)
            {
                Console.WriteLine("\n*************************************************");
                Console.WriteLine("\tGrade App");
                Console.WriteLine("Number of scores entered: {0}", numberOfScores);
                Console.WriteLine("Average: {0:f2}", average);
                Console.WriteLine("Grade: {0}", letterGrade);
                Console.WriteLine("****************************************************");
            }
        }
    }
}
